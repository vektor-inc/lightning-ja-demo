<?php
/**
* Modal Form for adding posts in bulk
* Populated via JS function
*/
?>
<div class="np-modal fade nestedpages" id="np-bulk-modal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-body new-child"></div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->