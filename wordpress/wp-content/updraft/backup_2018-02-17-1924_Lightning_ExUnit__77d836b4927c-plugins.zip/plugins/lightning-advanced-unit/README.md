# lightning-advanced-unit

Lightning 専用の機能拡張プラグイン  

Lightning 以外でも使うようなものは ExUnitに実装する
