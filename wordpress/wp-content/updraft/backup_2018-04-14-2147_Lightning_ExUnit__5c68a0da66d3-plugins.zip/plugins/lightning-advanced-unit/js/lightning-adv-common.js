/*
Advanced Unit 共通のJS
（ ligtning-adv.js は他のライブラリとの結合済み ）
 */