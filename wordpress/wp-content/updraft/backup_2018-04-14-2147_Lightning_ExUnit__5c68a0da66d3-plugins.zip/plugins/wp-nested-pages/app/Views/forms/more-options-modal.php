<?php
/**
* Modal with additional options for posts
*/
?>
<div class="np-modal fade np-trash-modal" id="np-more-options-modal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-body">
				
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->