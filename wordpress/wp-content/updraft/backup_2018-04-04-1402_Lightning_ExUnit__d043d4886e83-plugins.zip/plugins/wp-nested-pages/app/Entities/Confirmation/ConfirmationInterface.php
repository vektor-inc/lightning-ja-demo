<?php
namespace NestedPages\Entities\Confirmation;

interface ConfirmationInterface 
{
	/**
	* Display the Confirmation Message
	*/
	public function setMessage();
}