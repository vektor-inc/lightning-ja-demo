http_path = "/"
css_dir = "css"
sass_dir = "_scss"
images_dir = "images"
javascripts_dir = "js"
# output_style = :compact
output_style = :compressed
line_comments = false
cache = false
# sass_options = {:debug_info => false}