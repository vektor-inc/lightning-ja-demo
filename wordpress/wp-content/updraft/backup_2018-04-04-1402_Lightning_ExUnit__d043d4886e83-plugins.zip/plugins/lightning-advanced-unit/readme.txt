=== Plugin Name ===
Contributors: vektor-inc,bizvektor,kurudrive
Donate link:
Tags: Lightning,
Requires at least: 4.5
Tested up to: 4.9.1
Stable tag: 3.0.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is a plug-ins that extend the functionality of the theme "Lightning".

== Description ==

This is a plug-ins that extend the functionality of the theme "Lightning".

[ Powerful　Widgets ]

*   Full Wide Title Widget
*   Content area widget - Thumbnail / Date / Category / Excerpt
*   Content area widget - Thumbnail / Date / Category / Content

[ SlideMenu ]

*   You can choice menu type

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Set to customizer

== Frequently Asked Questions ==



== Screenshots ==



== Changelog ==

= 3.0.0 =
* [ Add function ] New Mobile Menu Release

= 2.6.1 =
* [ bug fix ] Add processing when there is no sidebar.

= 2.6.0 =
* [ Add function ] sidebar fix

= 2.5.0 =
* [ Add function ][ Fuull wide Widget ] Add text shadow.

= 2.2.0 =
* [ Specification change ] When active Origin Pro or Variety that, labal color active.

= 2.0.0 =
* [ Specification change ] Change mobile menu break point

= 1.3.6 =
* [ Specification change ] Work on Lightning only.

= 1.2.0 =
* [ Add function ] Sidebar position changer

= 1.1.0 =
* Added the filter to menu type items.

= 0.0.1 =
* Hellow world

== Upgrade Notice ==

Nothing.
