<?php

class Vk_Admin_Info {


}
